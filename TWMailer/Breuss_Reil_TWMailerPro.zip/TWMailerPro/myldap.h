#include <stdio.h>
#include <string>
#include <stdlib.h>
#include <ldap.h>
#include "mypw.h"


std::string ldapAuthentication(std::string username, std::string password);