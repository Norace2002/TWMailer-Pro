#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <iostream>
#include <string>

int getch();
std::string getpass();